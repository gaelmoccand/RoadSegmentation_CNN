# EPFL Machine Learning Course CS-433 - Project 1
Pascal Bienz, pascal.bienz@gmail.com & Gael Moccand, gael.moccand@gmail.com

* implementation.py: The 6 functions returning the w-parameters and the loss
* run.py: run it to generate the dataset which gave the best Kaggle score eg submission('train.csv','test.csv')
* proj1_helpers.py: helpers to load and generate data
